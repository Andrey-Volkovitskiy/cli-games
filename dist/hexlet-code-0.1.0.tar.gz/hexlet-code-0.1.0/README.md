### Hexlet tests and linter status:
[![Actions Status](https://github.com/Andrey-Volkovitskiy/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Andrey-Volkovitskiy/python-project-49/actions)

<a href="https://codeclimate.com/github/Andrey-Volkovitskiy/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b9dac5515a4f57ed4447/maintainability" /></a>

https://asciinema.org/connect/a46ea71e-db14-4484-abcd-c65cfe40b70b

https://asciinema.org/a/ej5ID0ckY85hqoBmiqDSzf7s9

https://asciinema.org/a/FjnAIqnbgzQcgugVcnQnbGn2u

https://asciinema.org/a/HIZibfktD3I6PTAZgaiMLka3z

https://asciinema.org/a/FQjTOIJ13QfKICzKcC8Yk3WUL